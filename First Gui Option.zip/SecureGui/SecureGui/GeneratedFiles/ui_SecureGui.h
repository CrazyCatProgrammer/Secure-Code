/********************************************************************************
** Form generated from reading UI file 'SecureGui.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SECUREGUI_H
#define UI_SECUREGUI_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SecureGuiClass
{
public:
    QWidget *centralWidget;
    QPushButton *pushButton;
    QLabel *label;
    QLabel *label_2;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QSpinBox *spinBox;
    QSpinBox *spinBox_2;
    QComboBox *comboBox;
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QCheckBox *checkBox_3;
    QComboBox *comboBox_2;
    QLabel *label_3;
    QLabel *label_4;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *SecureGuiClass)
    {
        if (SecureGuiClass->objectName().isEmpty())
            SecureGuiClass->setObjectName(QString::fromUtf8("SecureGuiClass"));
        SecureGuiClass->resize(600, 400);
        centralWidget = new QWidget(SecureGuiClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(500, 310, 75, 23));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 10, 121, 16));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 120, 121, 16));
        radioButton = new QRadioButton(centralWidget);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(420, 20, 82, 17));
        radioButton_2 = new QRadioButton(centralWidget);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(420, 40, 82, 17));
        spinBox = new QSpinBox(centralWidget);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(40, 30, 42, 22));
        spinBox_2 = new QSpinBox(centralWidget);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));
        spinBox_2->setGeometry(QRect(40, 140, 42, 22));
        comboBox = new QComboBox(centralWidget);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(420, 90, 69, 22));
        checkBox = new QCheckBox(centralWidget);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(420, 150, 70, 17));
        checkBox_2 = new QCheckBox(centralWidget);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setGeometry(QRect(420, 180, 70, 17));
        checkBox_3 = new QCheckBox(centralWidget);
        checkBox_3->setObjectName(QString::fromUtf8("checkBox_3"));
        checkBox_3->setGeometry(QRect(420, 210, 70, 17));
        comboBox_2 = new QComboBox(centralWidget);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(40, 200, 69, 22));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(40, 180, 101, 16));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(420, 70, 51, 16));
        SecureGuiClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(SecureGuiClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 600, 21));
        SecureGuiClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(SecureGuiClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        SecureGuiClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(SecureGuiClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        SecureGuiClass->setStatusBar(statusBar);

        retranslateUi(SecureGuiClass);

        QMetaObject::connectSlotsByName(SecureGuiClass);
    } // setupUi

    void retranslateUi(QMainWindow *SecureGuiClass)
    {
        SecureGuiClass->setWindowTitle(QApplication::translate("SecureGuiClass", "SecureGui", nullptr));
        pushButton->setText(QApplication::translate("SecureGuiClass", "Next", nullptr));
        label->setText(QApplication::translate("SecureGuiClass", "Number of Reservations", nullptr));
        label_2->setText(QApplication::translate("SecureGuiClass", "Number of Checked Bags", nullptr));
        radioButton->setText(QApplication::translate("SecureGuiClass", "One Way", nullptr));
        radioButton_2->setText(QApplication::translate("SecureGuiClass", "Round Trip", nullptr));
        comboBox->setItemText(0, QApplication::translate("SecureGuiClass", "AL", nullptr));
        comboBox->setItemText(1, QApplication::translate("SecureGuiClass", "AK", nullptr));
        comboBox->setItemText(2, QApplication::translate("SecureGuiClass", "AZ", nullptr));
        comboBox->setItemText(3, QApplication::translate("SecureGuiClass", "AR", nullptr));
        comboBox->setItemText(4, QApplication::translate("SecureGuiClass", "CA", nullptr));
        comboBox->setItemText(5, QApplication::translate("SecureGuiClass", "CO", nullptr));
        comboBox->setItemText(6, QApplication::translate("SecureGuiClass", "CT", nullptr));
        comboBox->setItemText(7, QApplication::translate("SecureGuiClass", "DE", nullptr));
        comboBox->setItemText(8, QApplication::translate("SecureGuiClass", "FL", nullptr));
        comboBox->setItemText(9, QApplication::translate("SecureGuiClass", "GA", nullptr));
        comboBox->setItemText(10, QApplication::translate("SecureGuiClass", "HI", nullptr));
        comboBox->setItemText(11, QApplication::translate("SecureGuiClass", "ID", nullptr));
        comboBox->setItemText(12, QApplication::translate("SecureGuiClass", "IL", nullptr));
        comboBox->setItemText(13, QApplication::translate("SecureGuiClass", "IN", nullptr));
        comboBox->setItemText(14, QApplication::translate("SecureGuiClass", "IA", nullptr));
        comboBox->setItemText(15, QApplication::translate("SecureGuiClass", "KS", nullptr));
        comboBox->setItemText(16, QApplication::translate("SecureGuiClass", "KY", nullptr));
        comboBox->setItemText(17, QApplication::translate("SecureGuiClass", "LA", nullptr));
        comboBox->setItemText(18, QApplication::translate("SecureGuiClass", "ME", nullptr));
        comboBox->setItemText(19, QApplication::translate("SecureGuiClass", "MD", nullptr));
        comboBox->setItemText(20, QApplication::translate("SecureGuiClass", "MA", nullptr));
        comboBox->setItemText(21, QApplication::translate("SecureGuiClass", "MI", nullptr));
        comboBox->setItemText(22, QApplication::translate("SecureGuiClass", "MN", nullptr));
        comboBox->setItemText(23, QApplication::translate("SecureGuiClass", "MS", nullptr));
        comboBox->setItemText(24, QApplication::translate("SecureGuiClass", "MO", nullptr));
        comboBox->setItemText(25, QApplication::translate("SecureGuiClass", "MT", nullptr));
        comboBox->setItemText(26, QApplication::translate("SecureGuiClass", "NE", nullptr));
        comboBox->setItemText(27, QApplication::translate("SecureGuiClass", "NV", nullptr));
        comboBox->setItemText(28, QApplication::translate("SecureGuiClass", "NH", nullptr));
        comboBox->setItemText(29, QApplication::translate("SecureGuiClass", "NJ", nullptr));
        comboBox->setItemText(30, QApplication::translate("SecureGuiClass", "NM", nullptr));
        comboBox->setItemText(31, QApplication::translate("SecureGuiClass", "NY", nullptr));
        comboBox->setItemText(32, QApplication::translate("SecureGuiClass", "NC", nullptr));
        comboBox->setItemText(33, QApplication::translate("SecureGuiClass", "ND", nullptr));
        comboBox->setItemText(34, QApplication::translate("SecureGuiClass", "OH", nullptr));
        comboBox->setItemText(35, QApplication::translate("SecureGuiClass", "OK", nullptr));
        comboBox->setItemText(36, QApplication::translate("SecureGuiClass", "OR", nullptr));
        comboBox->setItemText(37, QApplication::translate("SecureGuiClass", "PA", nullptr));
        comboBox->setItemText(38, QApplication::translate("SecureGuiClass", "RI", nullptr));
        comboBox->setItemText(39, QApplication::translate("SecureGuiClass", "SC", nullptr));
        comboBox->setItemText(40, QApplication::translate("SecureGuiClass", "SD", nullptr));
        comboBox->setItemText(41, QApplication::translate("SecureGuiClass", "TN", nullptr));
        comboBox->setItemText(42, QApplication::translate("SecureGuiClass", "TX", nullptr));
        comboBox->setItemText(43, QApplication::translate("SecureGuiClass", "UT", nullptr));
        comboBox->setItemText(44, QApplication::translate("SecureGuiClass", "VT", nullptr));
        comboBox->setItemText(45, QApplication::translate("SecureGuiClass", "VA", nullptr));
        comboBox->setItemText(46, QApplication::translate("SecureGuiClass", "WA", nullptr));
        comboBox->setItemText(47, QApplication::translate("SecureGuiClass", "WV", nullptr));
        comboBox->setItemText(48, QApplication::translate("SecureGuiClass", "WI", nullptr));
        comboBox->setItemText(49, QApplication::translate("SecureGuiClass", "WY", nullptr));

        checkBox->setText(QApplication::translate("SecureGuiClass", "First Class", nullptr));
        checkBox_2->setText(QApplication::translate("SecureGuiClass", "Economy", nullptr));
        checkBox_3->setText(QApplication::translate("SecureGuiClass", "Coach", nullptr));
        comboBox_2->setItemText(0, QApplication::translate("SecureGuiClass", "To", nullptr));
        comboBox_2->setItemText(1, QApplication::translate("SecureGuiClass", "From", nullptr));

        label_3->setText(QApplication::translate("SecureGuiClass", "What kind of Flight?", nullptr));
        label_4->setText(QApplication::translate("SecureGuiClass", "Where", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SecureGuiClass: public Ui_SecureGuiClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SECUREGUI_H
