#include "SecureGui.h"
#include "ui_SecureGui.h"
#include "ui_Info.h"
SecureGui::SecureGui(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

void SecureGui::on_pushButton_clicked()
{
	//connect pushButton to the next widget
	//https://www.youtube.com/watch?v=tP70B-pdTH0
}
