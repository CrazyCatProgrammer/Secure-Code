/*
DISCLAIMER!!!
This program has created a GUI using the Qt software, liscened under open source.
In compliance with (L)GPL regulations, this banner is the acknowledgement of Qt usage. For more information, visit https://www.qt.io/
This software is, and will remain, free of DRM locks and patents in compliance with these regulations.
This software is developed for educationial purposes as part of a project at Red Rocks Community College class CSC 245 040 Spring 2019
The students involved are Robyn Collins, Carson Sharpless
*/

#include "SecureGui.h"
#include <QtWidgets/QApplication> //brings in widgets for the application
#include <qlabel.h> //for labels in the application - HAHA JK

int main(int argc, char *argv[])
{
	QApplication a(argc, argv); //opens up the application
	SecureGui w; //just an empty window
	w.show();	// show window
	return a.exec();
}
