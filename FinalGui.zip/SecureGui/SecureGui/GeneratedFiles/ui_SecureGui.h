/********************************************************************************
** Form generated from reading UI file 'SecureGui.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SECUREGUI_H
#define UI_SECUREGUI_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SecureGuiClass
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QLabel *label_2;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QSpinBox *spinBox;
    QSpinBox *spinBox_2;
    QComboBox *comboBox;
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QCheckBox *checkBox_3;
    QComboBox *comboBox_2;
    QLabel *label_3;
    QLabel *label_4;
    QWidget *widget;
    QLabel *label_5;
    QLineEdit *lineEdit;
    QLabel *label_6;
    QLineEdit *lineEdit_2;
    QLabel *label_7;
    QLineEdit *lineEdit_3;
    QRadioButton *radioButton_3;
    QRadioButton *radioButton_4;
    QRadioButton *radioButton_5;
    QLabel *label_8;
    QPlainTextEdit *plainTextEdit;
    QFrame *frame;
    QLabel *label_9;
    QLabel *label_10;
    QLineEdit *lineEdit_4;
    QLabel *label_11;
    QLineEdit *lineEdit_5;
    QLabel *label_12;
    QDateEdit *dateEdit;
    QLabel *label_13;
    QComboBox *comboBox_3;
    QLabel *label_14;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *SecureGuiClass)
    {
        if (SecureGuiClass->objectName().isEmpty())
            SecureGuiClass->setObjectName(QString::fromUtf8("SecureGuiClass"));
        SecureGuiClass->resize(718, 588);
        centralWidget = new QWidget(SecureGuiClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 10, 121, 16));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 120, 121, 16));
        radioButton = new QRadioButton(centralWidget);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(200, 10, 82, 17));
        radioButton_2 = new QRadioButton(centralWidget);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(200, 30, 82, 17));
        spinBox = new QSpinBox(centralWidget);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(40, 30, 42, 22));
        spinBox_2 = new QSpinBox(centralWidget);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));
        spinBox_2->setGeometry(QRect(40, 140, 42, 22));
        comboBox = new QComboBox(centralWidget);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(200, 80, 69, 22));
        checkBox = new QCheckBox(centralWidget);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(190, 140, 70, 17));
        checkBox_2 = new QCheckBox(centralWidget);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setGeometry(QRect(190, 160, 70, 17));
        checkBox_3 = new QCheckBox(centralWidget);
        checkBox_3->setObjectName(QString::fromUtf8("checkBox_3"));
        checkBox_3->setGeometry(QRect(190, 180, 70, 17));
        comboBox_2 = new QComboBox(centralWidget);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(40, 200, 69, 22));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(40, 180, 101, 16));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(200, 60, 51, 16));
        widget = new QWidget(centralWidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(300, 10, 291, 231));
        label_5 = new QLabel(widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(0, 10, 47, 13));
        lineEdit = new QLineEdit(widget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(0, 30, 113, 16));
        label_6 = new QLabel(widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(120, 10, 47, 13));
        lineEdit_2 = new QLineEdit(widget);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(120, 30, 111, 16));
        label_7 = new QLabel(widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(240, 10, 47, 13));
        lineEdit_3 = new QLineEdit(widget);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(240, 30, 41, 16));
        radioButton_3 = new QRadioButton(widget);
        radioButton_3->setObjectName(QString::fromUtf8("radioButton_3"));
        radioButton_3->setGeometry(QRect(10, 50, 82, 17));
        radioButton_4 = new QRadioButton(widget);
        radioButton_4->setObjectName(QString::fromUtf8("radioButton_4"));
        radioButton_4->setGeometry(QRect(10, 70, 82, 17));
        radioButton_5 = new QRadioButton(widget);
        radioButton_5->setObjectName(QString::fromUtf8("radioButton_5"));
        radioButton_5->setGeometry(QRect(10, 90, 82, 17));
        label_8 = new QLabel(widget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(90, 110, 101, 20));
        plainTextEdit = new QPlainTextEdit(widget);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        plainTextEdit->setGeometry(QRect(50, 150, 181, 71));
        frame = new QFrame(centralWidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(10, 250, 401, 221));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        label_9 = new QLabel(frame);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(100, 0, 81, 21));
        label_10 = new QLabel(frame);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(10, 40, 101, 16));
        lineEdit_4 = new QLineEdit(frame);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(10, 60, 181, 20));
        label_11 = new QLabel(frame);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(210, 40, 47, 13));
        lineEdit_5 = new QLineEdit(frame);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(210, 60, 51, 20));
        label_12 = new QLabel(frame);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(10, 90, 91, 16));
        dateEdit = new QDateEdit(frame);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        dateEdit->setGeometry(QRect(10, 110, 110, 22));
        label_13 = new QLabel(frame);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(180, 120, 91, 16));
        comboBox_3 = new QComboBox(frame);
        comboBox_3->addItem(QString());
        comboBox_3->addItem(QString());
        comboBox_3->addItem(QString());
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));
        comboBox_3->setGeometry(QRect(280, 60, 69, 22));
        label_14 = new QLabel(frame);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(280, 40, 61, 16));
        SecureGuiClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(SecureGuiClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 718, 21));
        SecureGuiClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(SecureGuiClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        SecureGuiClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(SecureGuiClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        SecureGuiClass->setStatusBar(statusBar);

        retranslateUi(SecureGuiClass);

        QMetaObject::connectSlotsByName(SecureGuiClass);
    } // setupUi

    void retranslateUi(QMainWindow *SecureGuiClass)
    {
        SecureGuiClass->setWindowTitle(QApplication::translate("SecureGuiClass", "SecureGui", nullptr));
        label->setText(QApplication::translate("SecureGuiClass", "Number of Reservations", nullptr));
        label_2->setText(QApplication::translate("SecureGuiClass", "Number of Checked Bags", nullptr));
        radioButton->setText(QApplication::translate("SecureGuiClass", "One Way", nullptr));
        radioButton_2->setText(QApplication::translate("SecureGuiClass", "Round Trip", nullptr));
        comboBox->setItemText(0, QApplication::translate("SecureGuiClass", "AL", nullptr));
        comboBox->setItemText(1, QApplication::translate("SecureGuiClass", "AK", nullptr));
        comboBox->setItemText(2, QApplication::translate("SecureGuiClass", "AZ", nullptr));
        comboBox->setItemText(3, QApplication::translate("SecureGuiClass", "AR", nullptr));
        comboBox->setItemText(4, QApplication::translate("SecureGuiClass", "CA", nullptr));
        comboBox->setItemText(5, QApplication::translate("SecureGuiClass", "CO", nullptr));
        comboBox->setItemText(6, QApplication::translate("SecureGuiClass", "CT", nullptr));
        comboBox->setItemText(7, QApplication::translate("SecureGuiClass", "DE", nullptr));
        comboBox->setItemText(8, QApplication::translate("SecureGuiClass", "FL", nullptr));
        comboBox->setItemText(9, QApplication::translate("SecureGuiClass", "GA", nullptr));
        comboBox->setItemText(10, QApplication::translate("SecureGuiClass", "HI", nullptr));
        comboBox->setItemText(11, QApplication::translate("SecureGuiClass", "ID", nullptr));
        comboBox->setItemText(12, QApplication::translate("SecureGuiClass", "IL", nullptr));
        comboBox->setItemText(13, QApplication::translate("SecureGuiClass", "IN", nullptr));
        comboBox->setItemText(14, QApplication::translate("SecureGuiClass", "IA", nullptr));
        comboBox->setItemText(15, QApplication::translate("SecureGuiClass", "KS", nullptr));
        comboBox->setItemText(16, QApplication::translate("SecureGuiClass", "KY", nullptr));
        comboBox->setItemText(17, QApplication::translate("SecureGuiClass", "LA", nullptr));
        comboBox->setItemText(18, QApplication::translate("SecureGuiClass", "ME", nullptr));
        comboBox->setItemText(19, QApplication::translate("SecureGuiClass", "MD", nullptr));
        comboBox->setItemText(20, QApplication::translate("SecureGuiClass", "MA", nullptr));
        comboBox->setItemText(21, QApplication::translate("SecureGuiClass", "MI", nullptr));
        comboBox->setItemText(22, QApplication::translate("SecureGuiClass", "MN", nullptr));
        comboBox->setItemText(23, QApplication::translate("SecureGuiClass", "MS", nullptr));
        comboBox->setItemText(24, QApplication::translate("SecureGuiClass", "MO", nullptr));
        comboBox->setItemText(25, QApplication::translate("SecureGuiClass", "MT", nullptr));
        comboBox->setItemText(26, QApplication::translate("SecureGuiClass", "NE", nullptr));
        comboBox->setItemText(27, QApplication::translate("SecureGuiClass", "NV", nullptr));
        comboBox->setItemText(28, QApplication::translate("SecureGuiClass", "NH", nullptr));
        comboBox->setItemText(29, QApplication::translate("SecureGuiClass", "NJ", nullptr));
        comboBox->setItemText(30, QApplication::translate("SecureGuiClass", "NM", nullptr));
        comboBox->setItemText(31, QApplication::translate("SecureGuiClass", "NY", nullptr));
        comboBox->setItemText(32, QApplication::translate("SecureGuiClass", "NC", nullptr));
        comboBox->setItemText(33, QApplication::translate("SecureGuiClass", "ND", nullptr));
        comboBox->setItemText(34, QApplication::translate("SecureGuiClass", "OH", nullptr));
        comboBox->setItemText(35, QApplication::translate("SecureGuiClass", "OK", nullptr));
        comboBox->setItemText(36, QApplication::translate("SecureGuiClass", "OR", nullptr));
        comboBox->setItemText(37, QApplication::translate("SecureGuiClass", "PA", nullptr));
        comboBox->setItemText(38, QApplication::translate("SecureGuiClass", "RI", nullptr));
        comboBox->setItemText(39, QApplication::translate("SecureGuiClass", "SC", nullptr));
        comboBox->setItemText(40, QApplication::translate("SecureGuiClass", "SD", nullptr));
        comboBox->setItemText(41, QApplication::translate("SecureGuiClass", "TN", nullptr));
        comboBox->setItemText(42, QApplication::translate("SecureGuiClass", "TX", nullptr));
        comboBox->setItemText(43, QApplication::translate("SecureGuiClass", "UT", nullptr));
        comboBox->setItemText(44, QApplication::translate("SecureGuiClass", "VT", nullptr));
        comboBox->setItemText(45, QApplication::translate("SecureGuiClass", "VA", nullptr));
        comboBox->setItemText(46, QApplication::translate("SecureGuiClass", "WA", nullptr));
        comboBox->setItemText(47, QApplication::translate("SecureGuiClass", "WV", nullptr));
        comboBox->setItemText(48, QApplication::translate("SecureGuiClass", "WI", nullptr));
        comboBox->setItemText(49, QApplication::translate("SecureGuiClass", "WY", nullptr));

        checkBox->setText(QApplication::translate("SecureGuiClass", "First Class", nullptr));
        checkBox_2->setText(QApplication::translate("SecureGuiClass", "Economy", nullptr));
        checkBox_3->setText(QApplication::translate("SecureGuiClass", "Coach", nullptr));
        comboBox_2->setItemText(0, QApplication::translate("SecureGuiClass", "To", nullptr));
        comboBox_2->setItemText(1, QApplication::translate("SecureGuiClass", "From", nullptr));

        label_3->setText(QApplication::translate("SecureGuiClass", "What kind of Flight?", nullptr));
        label_4->setText(QApplication::translate("SecureGuiClass", "Where", nullptr));
        label_5->setText(QApplication::translate("SecureGuiClass", "First", nullptr));
        label_6->setText(QApplication::translate("SecureGuiClass", "Last", nullptr));
        label_7->setText(QApplication::translate("SecureGuiClass", "Middle", nullptr));
        radioButton_3->setText(QApplication::translate("SecureGuiClass", "MR", nullptr));
        radioButton_4->setText(QApplication::translate("SecureGuiClass", "MRS", nullptr));
        radioButton_5->setText(QApplication::translate("SecureGuiClass", "MS", nullptr));
        label_8->setText(QApplication::translate("SecureGuiClass", "Dietary Restrictions", nullptr));
        label_9->setText(QApplication::translate("SecureGuiClass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600; text-decoration: underline;\">Payment</span></p></body></html>", nullptr));
        label_10->setText(QApplication::translate("SecureGuiClass", "Credit Card Number", nullptr));
        label_11->setText(QApplication::translate("SecureGuiClass", "CID", nullptr));
        label_12->setText(QApplication::translate("SecureGuiClass", "Experation Date", nullptr));
        label_13->setText(QApplication::translate("SecureGuiClass", "Total: ", nullptr));
        comboBox_3->setItemText(0, QApplication::translate("SecureGuiClass", "Visa", nullptr));
        comboBox_3->setItemText(1, QApplication::translate("SecureGuiClass", "American Express", nullptr));
        comboBox_3->setItemText(2, QApplication::translate("SecureGuiClass", "Master", nullptr));

        label_14->setText(QApplication::translate("SecureGuiClass", "Card Type", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SecureGuiClass: public Ui_SecureGuiClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SECUREGUI_H
