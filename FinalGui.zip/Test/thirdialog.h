#ifndef THIRDIALOG_H
#define THIRDIALOG_H

#include <QDialog>

namespace Ui {
class ThirDialog;
}

class ThirDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ThirDialog(QWidget *parent = nullptr);
    ~ThirDialog();

private:
    Ui::ThirDialog *ui;
};

#endif // THIRDIALOG_H
