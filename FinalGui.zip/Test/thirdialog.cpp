#include "thirdialog.h"
#include "ui_thirdialog.h"

ThirDialog::ThirDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ThirDialog)
{
    ui->setupUi(this);
}

ThirDialog::~ThirDialog()
{
    delete ui;
}
