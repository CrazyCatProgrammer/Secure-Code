#include "secdialog.h"
#include "ui_secdialog.h"
#include "thirdialog.h"
secDialog::secDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::secDialog)
{
    ui->setupUi(this);
}

secDialog::~secDialog()
{
    delete ui;
}

void secDialog::on_pushButton_clicked()
{
    ThirDialog third;
    third.setModal(true);
    third.exec();
}
