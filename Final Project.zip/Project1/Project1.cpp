// Project1.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "Project1.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;                                // current instance
WCHAR szTitle[MAX_LOADSTRING];                  // The title bar text
WCHAR szWindowClass[MAX_LOADSTRING];            // the main window class name

// Forward declarations of functions included in this code module:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);
void				AddControls(HWND);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR    lpCmdLine,
	_In_ int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// TODO: Place code here.

	// Initialize global strings
	LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadStringW(hInstance, IDC_PROJECT1, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow))
	{
		return FALSE;
	}

	HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_PROJECT1));

	MSG msg;

	// Main message loop:
	while (GetMessage(&msg, nullptr, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int)msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEXW wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_PROJECT1));
	wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_PROJECT1);
	wcex.lpszClassName = szWindowClass;
	wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassExW(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	hInst = hInstance; // Store instance handle in our global variable

	HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 400, CW_USEDEFAULT, 400, nullptr, nullptr, hInstance, nullptr);

	if (!hWnd)
	{
		return FALSE;
	}

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE: Processes messages for the main window.
//
//  WM_COMMAND  - process the application menu
//  WM_PAINT    - Paint the main window
//  WM_DESTROY  - post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_COMMAND:
	{
		int wmId = LOWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
	}
	break;
	case WM_PAINT:
	{
		LPCWSTR greeting = L" ";
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		// TODO: Add any drawing code that uses hdc here...
		TextOut(hdc,
			5, 5,
			greeting, _tcslen(greeting));
		EndPaint(hWnd, &ps);
		AddControls(hWnd);
	}
	break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

void AddControls(HWND hWnd)
{
	CreateWindowW(L"static", L"First Name", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 0, 5, 105, 50, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"Edit", L" ", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_MULTILINE | ES_AUTOHSCROLL | ES_AUTOVSCROLL, 1, 25, 100, 20, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"static", L"Last Name", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 105, 5, 105, 50, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"Edit", L" ", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_MULTILINE | ES_AUTOHSCROLL | ES_AUTOVSCROLL, 108, 25, 100, 20, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"static", L"Middle Initial", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 210, 5, 100, 50, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"Edit", L" ", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL | ES_AUTOVSCROLL, 250, 25, 25, 25, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"static", L"Number of Reservations", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 0, 55, 225, 50, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"Edit", L" ", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL | ES_AUTOVSCROLL, 80, 75, 50, 25, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"static", L"MR/MRS./MS. BUTTON RADIAL BUTTON WILL GO HERE", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 0, 105, 225, 50, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"static", L"DROPDOWN MENU/BUTTON FOR TO/FROM SELECTION OF FLIGHT HERE", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 0, 155, 225, 50, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"static", L"Number of Checked Bags", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 0, 205, 225, 50, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"Edit", L" ", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL | ES_AUTOVSCROLL, 80, 225, 50, 25, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"static", L"Round Trip / One Way Radial button will be placed here.", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 225, 55, 85, 100, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"static", L"Direct Flight or Trip with Connections Option", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 225, 155, 85, 100, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"static", L"Option of First Class, economy or coach", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 225, 255, 85, 100, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"static", L"Please enter any and all dietary restrictions that you might have", WS_VISIBLE | WS_CHILD | WS_BORDER | SS_CENTER, 0, 255, 225, 100, hWnd, NULL, NULL, NULL);
	CreateWindowW(L"Edit", L" ", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL | ES_AUTOVSCROLL, 40, 295, 130, 50, hWnd, NULL, NULL, NULL);
	CreateWindow(L"Button", L"Confirm Details and move to Payment", WS_VISIBLE | WS_CHILD, 0, 355, 310, 50, hWnd, NULL, NULL, NULL);
}