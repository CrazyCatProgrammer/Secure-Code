#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_SecureGui.h"
#include "ui_Info.h"

class SecureGui : public QMainWindow
{
	Q_OBJECT

public:
	SecureGui(QWidget *parent = Q_NULLPTR);

private:
	Ui::SecureGuiClass ui;
	void on_pushButton_clicked();
};
