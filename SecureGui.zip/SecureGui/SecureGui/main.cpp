#include "SecureGui.h"
#include <QtWidgets/QApplication> //brings in widgets for the application
#include <qlabel.h> //for labels in the application - HAHA JK

int main(int argc, char *argv[])
{
	QApplication a(argc, argv); //opens up the application
	SecureGui w; //just an empty window
	w.show();
	return a.exec();
}
